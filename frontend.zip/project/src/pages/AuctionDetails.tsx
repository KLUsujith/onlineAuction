import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Eye, Clock, ArrowUp, ArrowDown, Heart, Share2, Flag, 
  InfoIcon, DollarSign, Shield, Check, AlertTriangle 
} from 'lucide-react';
import { useAuction } from '../hooks/useAuction';
import { useAuth } from '../hooks/useAuth';
import { cn } from '../utils/cn';
import toast from 'react-hot-toast';

const AuctionDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { getAuctionById, placeBid, toggleWatchlist } = useAuction();
  const { user } = useAuth();
  const [bidAmount, setBidAmount] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const auction = getAuctionById(id || '');
  
  if (!auction) {
    return (
      <div className="min-h-screen pt-24 pb-16 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Auction Not Found</h1>
          <p className="text-gray-600 mb-6">
            The auction you're looking for may have been removed or doesn't exist.
          </p>
          <Link to="/auctions" className="btn btn-primary">
            Browse Auctions
          </Link>
        </div>
      </div>
    );
  }
  
  const isStandardAuction = auction.type === 'standard';
  const isUserSeller = auction.sellerId === user?.id;
  const timeLeft = new Date(auction.endDate).getTime() - new Date().getTime();
  const isEnded = timeLeft <= 0;
  
  // Calculate days, hours, minutes left
  const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
  const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
  
  // For standard auctions, minimum bid is current price + 5%
  // For reverse auctions, maximum bid is current price - 5%
  const minBid = isStandardAuction 
    ? Math.ceil(auction.currentPrice * 1.05) 
    : 0;
  
  const maxBid = !isStandardAuction 
    ? Math.floor(auction.currentPrice * 0.95)
    : Infinity;
  
  const handleBidSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast.error('Please log in to place a bid');
      return;
    }
    
    if (isUserSeller) {
      toast.error('You cannot bid on your own auction');
      return;
    }
    
    if (isEnded) {
      toast.error('This auction has ended');
      return;
    }
    
    const amount = parseFloat(bidAmount);
    
    if (isNaN(amount)) {
      toast.error('Please enter a valid amount');
      return;
    }
    
    if (isStandardAuction && amount < minBid) {
      toast.error(`Bid must be at least $${minBid}`);
      return;
    }
    
    if (!isStandardAuction && amount > maxBid) {
      toast.error(`Bid must be at most $${maxBid}`);
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      await placeBid(auction.id, user.id, user.name, amount);
      toast.success(`Bid of $${amount.toLocaleString()} placed successfully!`);
      setBidAmount('');
    } catch (error) {
      toast.error('Failed to place bid. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleWatchlist = () => {
    if (!user) {
      toast.error('Please log in to add to watchlist');
      return;
    }
    
    toggleWatchlist(auction.id);
    toast.success('Added to watchlist');
  };
  
  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4">
        {/* Breadcrumbs */}
        <nav className="mb-8">
          <ol className="flex items-center text-sm">
            <li>
              <Link to="/" className="text-gray-500 hover:text-gray-900">Home</Link>
            </li>
            <li className="mx-2 text-gray-400">/</li>
            <li>
              <Link to="/auctions" className="text-gray-500 hover:text-gray-900">Auctions</Link>
            </li>
            <li className="mx-2 text-gray-400">/</li>
            <li className="text-gray-900 font-medium truncate">{auction.title}</li>
          </ol>
        </nav>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* Left Column - Images */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-200 mb-8">
              <div className="relative h-[400px]">
                <img 
                  src={auction.imageUrl} 
                  alt={auction.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 left-4 right-4 flex justify-between">
                  <span className={cn(
                    "badge",
                    isStandardAuction 
                      ? "bg-primary text-white" 
                      : "bg-secondary text-gray-900"
                  )}>
                    {isStandardAuction ? 'Standard Auction' : 'Reverse Auction'}
                  </span>
                  <div className="flex space-x-2">
                    <span className="badge badge-outline bg-white">
                      <Eye size={14} className="mr-1" />
                      {auction.watchCount + Math.floor(Math.random() * 50)}
                    </span>
                    <span className="badge badge-outline bg-white">
                      <Clock size={14} className="mr-1" />
                      {isEnded ? (
                        'Ended'
                      ) : (
                        `${days}d ${hours}h ${minutes}m`
                      )}
                    </span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Auction details */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">{auction.title}</h1>
              <div className="flex flex-wrap items-center gap-4 mb-6">
                <div className="flex items-center">
                  <span className="text-gray-600 font-medium">Category:</span>
                  <span className="ml-2 badge badge-outline">{auction.category}</span>
                </div>
                <div className="flex items-center">
                  <span className="text-gray-600 font-medium">Seller:</span>
                  <Link to={`/seller/${auction.sellerId}`} className="ml-2 text-primary hover:underline">
                    {auction.sellerName}
                  </Link>
                </div>
                <div className="flex items-center">
                  <span className="text-gray-600 font-medium">Started:</span>
                  <span className="ml-2 text-gray-900">
                    {auction.startDate.toLocaleDateString()}
                  </span>
                </div>
              </div>
              
              <div className="border-t border-gray-200 pt-6 mb-6">
                <h2 className="text-xl font-semibold mb-4">Description</h2>
                <p className="text-gray-700 whitespace-pre-line leading-relaxed">
                  {auction.description}
                </p>
              </div>
              
              <div className="flex flex-wrap gap-3">
                <button 
                  onClick={handleWatchlist}
                  className="btn btn-outline flex items-center"
                >
                  <Heart size={18} className="mr-2" />
                  Watch
                </button>
                <button className="btn btn-outline flex items-center">
                  <Share2 size={18} className="mr-2" />
                  Share
                </button>
                <button className="btn btn-outline flex items-center text-red-500 hover:bg-red-50">
                  <Flag size={18} className="mr-2" />
                  Report
                </button>
              </div>
            </div>
            
            {/* Bid History */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold">Bid History</h2>
              </div>
              <div className="divide-y divide-gray-200">
                {auction.bids.length === 0 ? (
                  <div className="p-6 text-center text-gray-500">
                    No bids yet. Be the first to bid!
                  </div>
                ) : (
                  auction.bids
                    .slice()
                    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
                    .map(bid => (
                      <div key={bid.id} className="p-4 flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center text-gray-700 font-medium">
                            {bid.userName.charAt(0).toUpperCase()}
                          </div>
                          <div className="ml-3">
                            <p className="font-medium">{bid.userName}</p>
                            <p className="text-sm text-gray-500">
                              {new Date(bid.timestamp).toLocaleString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center">
                          <span className={cn(
                            "flex items-center text-sm font-medium mr-2",
                            isStandardAuction ? "text-green-600" : "text-red-600"
                          )}>
                            {isStandardAuction ? (
                              <ArrowUp size={14} className="mr-1" />
                            ) : (
                              <ArrowDown size={14} className="mr-1" />
                            )}
                            {isStandardAuction ? 'Bid' : 'Offer'}
                          </span>
                          <span className="text-lg font-bold">${bid.amount.toLocaleString()}</span>
                        </div>
                      </div>
                    ))
                )}
              </div>
            </div>
          </div>
          
          {/* Right Column - Bid Info & Form */}
          <div className="lg:col-span-1">
            {/* Bid Info Card */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8 sticky top-28">
              <div className="mb-6">
                <h2 className="text-lg text-gray-600 mb-1">
                  {isStandardAuction ? 'Current Bid' : 'Current Offer'}:
                </h2>
                <p className="text-3xl font-bold text-gray-900">
                  ${auction.currentPrice.toLocaleString()}
                </p>
                <p className="text-sm text-gray-500 mt-1">
                  {auction.bids.length} {auction.bids.length === 1 ? 'bid' : 'bids'} so far
                </p>
              </div>
              
              <div className="mb-6 flex items-center p-3 rounded-lg bg-blue-50 text-blue-800">
                <Clock size={20} className="mr-3 flex-shrink-0" />
                <div>
                  <p className="font-medium">
                    {isEnded ? 'Auction has ended' : 'Time Remaining:'}
                  </p>
                  {!isEnded && (
                    <p>
                      {days} days, {hours} hours, {minutes} minutes
                    </p>
                  )}
                </div>
              </div>
              
              {/* Bid Form */}
              {!isEnded && !isUserSeller && (
                <form onSubmit={handleBidSubmit} className="mb-6">
                  <div className="mb-4">
                    <label htmlFor="bidAmount" className="block text-sm font-medium text-gray-700 mb-1">
                      Your {isStandardAuction ? 'Bid' : 'Offer'} Amount
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <DollarSign size={18} className="text-gray-500" />
                      </div>
                      <input
                        type="number"
                        id="bidAmount"
                        className="input pl-9"
                        placeholder={isStandardAuction ? `Min. bid $${minBid}` : `Max. offer $${maxBid}`}
                        value={bidAmount}
                        onChange={(e) => setBidAmount(e.target.value)}
                        min={isStandardAuction ? minBid : 0}
                        max={!isStandardAuction ? maxBid : undefined}
                        step="0.01"
                        required
                      />
                    </div>
                    
                    <p className="mt-2 text-sm text-gray-600">
                      {isStandardAuction ? (
                        <>
                          Minimum bid is <strong>${minBid}</strong> 
                          <span className="text-gray-500"> (current bid + 5%)</span>
                        </>
                      ) : (
                        <>
                          Maximum offer is <strong>${maxBid}</strong>
                          <span className="text-gray-500"> (current offer - 5%)</span>
                        </>
                      )}
                    </p>
                  </div>
                  
                  <button
                    type="submit"
                    className={cn(
                      "btn w-full mb-4",
                      isStandardAuction ? "btn-primary" : "btn-secondary"
                    )}
                    disabled={isSubmitting || !user}
                  >
                    {isSubmitting ? 'Processing...' : isStandardAuction ? 'Place Bid' : 'Submit Offer'}
                  </button>
                  
                  {!user && (
                    <p className="text-sm text-red-600 text-center mb-4">
                      <Link to="/login" className="font-medium hover:underline">Sign in</Link>
                      {' '}to place a {isStandardAuction ? 'bid' : 'offer'}
                    </p>
                  )}
                </form>
              )}
              
              {/* Security Notice */}
              <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                <h3 className="flex items-center text-sm font-medium text-gray-900 mb-2">
                  <Shield size={16} className="mr-2 text-green-600" />
                  Secure Transaction
                </h3>
                <ul className="space-y-2">
                  <SecurityItem text="Buyer protection program" />
                  <SecurityItem text="Secure payment escrow" />
                  <SecurityItem text="Verified seller profile" />
                </ul>
                <div className="mt-3">
                  <button className="text-xs text-primary hover:underline flex items-center">
                    <InfoIcon size={12} className="mr-1" />
                    Learn more about buyer protection
                  </button>
                </div>
              </div>
              
              {/* Related Auctions - would be added here */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

interface SecurityItemProps {
  text: string;
}

const SecurityItem: React.FC<SecurityItemProps> = ({ text }) => (
  <li className="flex items-start">
    <Check size={14} className="mr-2 mt-0.5 text-green-600" />
    <span className="text-xs text-gray-700">{text}</span>
  </li>
);

export default AuctionDetails;