import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { PlusCircle, Clock, BellDot, Package, Send, DollarSign, User, ArrowDownUp, UserCheck } from 'lucide-react';
import { useAuction } from '../hooks/useAuction';
import { useAuth } from '../hooks/useAuth';
import { cn } from '../utils/cn';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const { getUserAuctions } = useAuction();
  const [activeTab, setActiveTab] = useState<string>('all');
  
  // Get user's auctions
  const userAuctions = getUserAuctions(user?.id || '');
  
  // Filter auctions based on active tab
  const filteredAuctions = userAuctions.filter(auction => {
    if (activeTab === 'all') return true;
    if (activeTab === 'selling') return auction.sellerId === user?.id;
    if (activeTab === 'bidding') return auction.sellerId !== user?.id;
    if (activeTab === 'standard') return auction.type === 'standard';
    if (activeTab === 'reverse') return auction.type === 'reverse';
    if (activeTab === 'active') return auction.status === 'active';
    if (activeTab === 'ended') return auction.status === 'ended';
    return true;
  });
  
  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4">
        <header className="mb-10">
          <div className="flex justify-between items-center flex-wrap gap-4 mb-6">
            <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
            <Link to="/create-auction" className="btn btn-primary">
              <PlusCircle size={18} className="mr-2" />
              Create Auction
            </Link>
          </div>
          
          {/* Overview Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <DashboardCard 
              icon={<Package className="text-primary" />}
              title="Active Listings"
              value={userAuctions.filter(a => a.sellerId === user?.id && a.status === 'active').length.toString()}
              to="/dashboard?filter=selling"
            />
            <DashboardCard 
              icon={<Send className="text-secondary" />}
              title="Active Bids"
              value={userAuctions.filter(a => a.sellerId !== user?.id && a.status === 'active').length.toString()}
              to="/dashboard?filter=bidding"
            />
            <DashboardCard 
              icon={<Clock className="text-amber-500" />}
              title="Ending Soon"
              value={userAuctions.filter(a => {
                const timeLeft = a.endDate.getTime() - new Date().getTime();
                const hoursLeft = timeLeft / (1000 * 60 * 60);
                return a.status === 'active' && hoursLeft < 24;
              }).length.toString()}
              to="/dashboard?filter=active"
            />
            <DashboardCard 
              icon={<BellDot className="text-red-500" />}
              title="Notifications"
              value="4"
              to="/notifications"
              highlight
            />
          </div>
        </header>
        
        {/* Tabs and Content */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          {/* Tabs */}
          <div className="flex overflow-x-auto scrollbar-hide border-b border-gray-200">
            <TabButton 
              active={activeTab === 'all'} 
              onClick={() => setActiveTab('all')}
            >
              All Auctions
            </TabButton>
            <TabButton 
              active={activeTab === 'selling'} 
              onClick={() => setActiveTab('selling')}
              icon={<DollarSign size={16} />}
            >
              Selling
            </TabButton>
            <TabButton 
              active={activeTab === 'bidding'} 
              onClick={() => setActiveTab('bidding')}
              icon={<User size={16} />}
            >
              Bidding
            </TabButton>
            <TabButton 
              active={activeTab === 'standard'} 
              onClick={() => setActiveTab('standard')}
              icon={<ArrowDownUp size={16} />}
            >
              Standard
            </TabButton>
            <TabButton 
              active={activeTab === 'reverse'} 
              onClick={() => setActiveTab('reverse')}
              icon={<UserCheck size={16} />}
            >
              Reverse
            </TabButton>
            <TabButton 
              active={activeTab === 'active'} 
              onClick={() => setActiveTab('active')}
              icon={<Clock size={16} />}
            >
              Active
            </TabButton>
            <TabButton 
              active={activeTab === 'ended'} 
              onClick={() => setActiveTab('ended')}
            >
              Ended
            </TabButton>
          </div>
          
          {/* Auction List */}
          <div className="divide-y divide-gray-200">
            {filteredAuctions.length === 0 ? (
              <div className="py-20 text-center">
                <p className="text-gray-500 mb-4">No auctions found for this filter</p>
                <Link to="/create-auction" className="btn btn-outline">
                  Create Your First Auction
                </Link>
              </div>
            ) : (
              filteredAuctions.map(auction => (
                <div 
                  key={auction.id}
                  className="p-4 sm:p-6 hover:bg-gray-50 transition-colors"
                >
                  <div className="flex flex-col sm:flex-row">
                    <div className="sm:w-16 sm:h-16 w-full h-32 mb-4 sm:mb-0 sm:mr-4 rounded-lg overflow-hidden">
                      <img 
                        src={auction.imageUrl} 
                        alt={auction.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-grow">
                      <div className="flex flex-wrap justify-between mb-2">
                        <Link 
                          to={`/auction/${auction.id}`}
                          className="text-lg font-semibold hover:text-primary transition-colors"
                        >
                          {auction.title}
                        </Link>
                        <div className="flex space-x-2">
                          <span className={cn(
                            "badge",
                            auction.type === 'standard' 
                              ? "bg-primary text-white" 
                              : "bg-secondary text-gray-900"
                          )}>
                            {auction.type === 'standard' ? 'Standard' : 'Reverse'}
                          </span>
                          <span className={cn(
                            "badge",
                            auction.status === 'active' 
                              ? "bg-green-500 text-white" 
                              : auction.status === 'upcoming'
                                ? "bg-blue-500 text-white"
                                : "bg-gray-500 text-white"
                          )}>
                            {auction.status.charAt(0).toUpperCase() + auction.status.slice(1)}
                          </span>
                        </div>
                      </div>
                      <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                        {auction.description}
                      </p>
                      <div className="flex flex-wrap justify-between items-end">
                        <div>
                          <p className="text-sm text-gray-500">
                            {auction.type === 'standard' ? 'Current Bid' : 'Current Offer'}
                          </p>
                          <p className="text-xl font-bold text-gray-900">
                            ${auction.currentPrice.toLocaleString()}
                          </p>
                        </div>
                        <div className="flex flex-col items-end">
                          <div className="flex items-center text-sm text-gray-500 mb-2">
                            <Clock size={14} className="mr-1" />
                            {auction.status === 'ended' ? (
                              'Auction ended'
                            ) : (
                              `Ends in ${Math.ceil((auction.endDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} days`
                            )}
                          </div>
                          <Link 
                            to={`/auction/${auction.id}`}
                            className="btn btn-sm btn-outline"
                          >
                            View Details
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

interface DashboardCardProps {
  icon: React.ReactNode;
  title: string;
  value: string;
  to: string;
  highlight?: boolean;
}

const DashboardCard: React.FC<DashboardCardProps> = ({ 
  icon, 
  title, 
  value, 
  to,
  highlight = false
}) => (
  <Link 
    to={to}
    className={cn(
      "block p-6 rounded-lg border transition-all",
      highlight 
        ? "bg-primary text-white border-primary hover:bg-primary/90"
        : "bg-white border-gray-200 hover:border-primary/30 hover:shadow-md"
    )}
  >
    <div className="flex items-center mb-4">
      <div className={cn(
        "w-10 h-10 rounded-full flex items-center justify-center",
        highlight 
          ? "bg-white/20" 
          : "bg-gray-100"
      )}>
        {icon}
      </div>
    </div>
    <h3 className={cn(
      "text-lg font-medium mb-1",
      highlight ? "text-white" : "text-gray-500"
    )}>
      {title}
    </h3>
    <p className={cn(
      "text-2xl font-bold",
      highlight ? "text-white" : "text-gray-900"
    )}>
      {value}
    </p>
  </Link>
);

interface TabButtonProps {
  active: boolean;
  onClick: () => void;
  icon?: React.ReactNode;
  children: React.ReactNode;
}

const TabButton: React.FC<TabButtonProps> = ({ 
  active, 
  onClick, 
  icon, 
  children 
}) => (
  <button
    className={cn(
      "px-4 py-3 text-sm font-medium whitespace-nowrap focus:outline-none transition-colors flex items-center",
      active 
        ? "border-b-2 border-primary text-primary" 
        : "text-gray-500 hover:text-gray-700 hover:bg-gray-50"
    )}
    onClick={onClick}
  >
    {icon && <span className="mr-2">{icon}</span>}
    {children}
  </button>
);

export default Dashboard;