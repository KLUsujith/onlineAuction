import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useAuction } from '../hooks/useAuction';
import { Clock, Edit, Mail, MapPin, Phone, User, Settings, Shield, Star, ExternalLink, HelpCircle, LogOut } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { cn } from '../utils/cn';
import toast from 'react-hot-toast';

const Profile: React.FC = () => {
  const { user, logout } = useAuth();
  const { getUserAuctions } = useAuction();
  const [activeTab, setActiveTab] = useState('auctions');
  const navigate = useNavigate();
  
  const handleLogout = () => {
    logout();
    navigate('/login');
    toast.success('Logged out successfully');
  };
  
  const userAuctions = getUserAuctions(user?.id || '');
  
  if (!user) {
    return (
      <div className="min-h-screen pt-24 pb-16 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Not Logged In</h1>
          <p className="text-gray-600 mb-6">Please log in to view your profile</p>
          <Link to="/login" className="btn btn-primary">
            Sign In
          </Link>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Profile Info */}
          <div className="lg:col-span-1">
            {/* Profile Card */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden mb-6">
              {/* Cover Photo */}
              <div className="h-32 bg-gradient-to-r from-primary to-blue-700"></div>
              
              {/* Profile Information */}
              <div className="px-6 pb-6">
                {/* Avatar */}
                <div className="-mt-12 mb-4 flex justify-between items-end">
                  <div className="w-24 h-24 rounded-full bg-white p-1">
                    <div className="w-full h-full rounded-full bg-primary/10 flex items-center justify-center text-primary text-3xl font-bold">
                      {user.name.charAt(0).toUpperCase()}
                    </div>
                  </div>
                  <button className="btn btn-sm btn-outline">
                    <Edit size={14} className="mr-1" />
                    Edit
                  </button>
                </div>
                
                <h1 className="text-2xl font-bold text-gray-900 mb-1">{user.name}</h1>
                <p className="text-gray-500 mb-4">Member since {new Date().toLocaleDateString()}</p>
                
                <div className="space-y-3 mb-6">
                  <div className="flex items-center text-gray-600">
                    <Mail size={18} className="mr-3" />
                    <span>{user.email}</span>
                  </div>
                  <div className="flex items-center text-gray-600">
                    <MapPin size={18} className="mr-3" />
                    <span>San Francisco, CA</span>
                  </div>
                  <div className="flex items-center text-gray-600">
                    <Phone size={18} className="mr-3" />
                    <span>+1 (555) 123-4567</span>
                  </div>
                </div>
                
                <div className="flex space-x-3 mb-4">
                  <div className="flex-1 text-center p-3 bg-gray-50 rounded-lg">
                    <p className="text-2xl font-bold text-gray-900">
                      {userAuctions.filter(a => a.sellerId === user.id).length}
                    </p>
                    <p className="text-xs font-medium text-gray-500">Auctions</p>
                  </div>
                  <div className="flex-1 text-center p-3 bg-gray-50 rounded-lg">
                    <p className="text-2xl font-bold text-gray-900">
                      {userAuctions.filter(a => a.sellerId !== user.id).length}
                    </p>
                    <p className="text-xs font-medium text-gray-500">Bids</p>
                  </div>
                  <div className="flex-1 text-center p-3 bg-gray-50 rounded-lg">
                    <p className="text-2xl font-bold text-primary">100%</p>
                    <p className="text-xs font-medium text-gray-500">Rating</p>
                  </div>
                </div>
                
                <div className="flex space-x-3">
                  <div className="flex items-center text-sm text-green-600">
                    <Shield size={14} className="mr-1" />
                    Verified
                  </div>
                  <div className="flex items-center text-sm text-amber-600">
                    <Star size={14} className="mr-1" />
                    Top Seller
                  </div>
                </div>
              </div>
            </div>
            
            {/* Navigation */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
              <nav className="divide-y divide-gray-200">
                <NavItem
                  icon={<User size={18} />}
                  label="My Account"
                  active={activeTab === 'account'}
                  onClick={() => setActiveTab('account')}
                />
                <NavItem
                  icon={<Clock size={18} />}
                  label="My Auctions"
                  active={activeTab === 'auctions'}
                  onClick={() => setActiveTab('auctions')}
                />
                <NavItem
                  icon={<Settings size={18} />}
                  label="Settings"
                  active={activeTab === 'settings'}
                  onClick={() => setActiveTab('settings')}
                />
                <NavItem
                  icon={<Shield size={18} />}
                  label="Security"
                  active={activeTab === 'security'}
                  onClick={() => setActiveTab('security')}
                />
                <NavItem
                  icon={<HelpCircle size={18} />}
                  label="Help & Support"
                  active={activeTab === 'help'}
                  onClick={() => setActiveTab('help')}
                />
                <button
                  className="flex items-center w-full px-4 py-3 text-left hover:bg-red-50 text-red-600"
                  onClick={handleLogout}
                >
                  <LogOut size={18} className="mr-3" />
                  <span>Logout</span>
                </button>
              </nav>
            </div>
          </div>
          
          {/* Right Column - Content */}
          <div className="lg:col-span-2">
            {activeTab === 'auctions' && (
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h2 className="text-xl font-semibold">My Auctions & Bids</h2>
                </div>
                
                {userAuctions.length === 0 ? (
                  <div className="p-8 text-center">
                    <p className="text-gray-500 mb-4">You don't have any auctions or bids yet</p>
                    <Link to="/create-auction" className="btn btn-primary">
                      Create Your First Auction
                    </Link>
                  </div>
                ) : (
                  <div className="divide-y divide-gray-200">
                    {userAuctions.map(auction => (
                      <div 
                        key={auction.id}
                        className="p-4 sm:p-6 hover:bg-gray-50 transition-colors"
                      >
                        <div className="flex flex-col sm:flex-row">
                          <div className="sm:w-16 sm:h-16 w-full h-32 mb-4 sm:mb-0 sm:mr-4 rounded-lg overflow-hidden">
                            <img 
                              src={auction.imageUrl} 
                              alt={auction.title}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="flex-grow">
                            <div className="flex flex-wrap justify-between mb-2">
                              <Link 
                                to={`/auction/${auction.id}`}
                                className="text-lg font-semibold hover:text-primary transition-colors"
                              >
                                {auction.title}
                              </Link>
                              <div className="flex space-x-2">
                                <span className={cn(
                                  "badge text-xs",
                                  auction.sellerId === user.id 
                                    ? "bg-primary text-white" 
                                    : "bg-secondary text-gray-900"
                                )}>
                                  {auction.sellerId === user.id ? 'Selling' : 'Bidding'}
                                </span>
                                <span className={cn(
                                  "badge text-xs",
                                  auction.type === 'standard' 
                                    ? "bg-blue-500 text-white" 
                                    : "bg-amber-500 text-white"
                                )}>
                                  {auction.type === 'standard' ? 'Standard' : 'Reverse'}
                                </span>
                              </div>
                            </div>
                            <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                              {auction.description}
                            </p>
                            <div className="flex flex-wrap justify-between items-end">
                              <div>
                                <p className="text-sm text-gray-500">
                                  {auction.type === 'standard' ? 'Current Bid' : 'Current Offer'}
                                </p>
                                <p className="text-xl font-bold text-gray-900">
                                  ${auction.currentPrice.toLocaleString()}
                                </p>
                              </div>
                              <div className="flex items-center space-x-3">
                                <div className="text-sm text-gray-500">
                                  <Clock size={14} className="inline mr-1" />
                                  {new Date() > new Date(auction.endDate) 
                                    ? 'Ended' 
                                    : `${Math.ceil((new Date(auction.endDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} days left`
                                  }
                                </div>
                                <Link 
                                  to={`/auction/${auction.id}`}
                                  className="btn btn-sm btn-outline flex items-center"
                                >
                                  <ExternalLink size={14} className="mr-1" />
                                  View
                                </Link>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
            
            {activeTab === 'account' && (
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden p-6">
                <h2 className="text-xl font-semibold mb-6">Account Information</h2>
                <p className="text-gray-600 mb-4">
                  This is where you can manage your account information and preferences.
                </p>
                <p className="text-sm text-gray-500">
                  This section is under development.
                </p>
              </div>
            )}
            
            {activeTab === 'settings' && (
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden p-6">
                <h2 className="text-xl font-semibold mb-6">Settings</h2>
                <p className="text-gray-600 mb-4">
                  Control your notification preferences and account settings.
                </p>
                <p className="text-sm text-gray-500">
                  This section is under development.
                </p>
              </div>
            )}
            
            {activeTab === 'security' && (
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden p-6">
                <h2 className="text-xl font-semibold mb-6">Security</h2>
                <p className="text-gray-600 mb-4">
                  Manage your security settings, change your password, and set up two-factor authentication.
                </p>
                <p className="text-sm text-gray-500">
                  This section is under development.
                </p>
              </div>
            )}
            
            {activeTab === 'help' && (
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden p-6">
                <h2 className="text-xl font-semibold mb-6">Help & Support</h2>
                <p className="text-gray-600 mb-4">
                  Get help with your account, bidding, or any other questions you may have.
                </p>
                <p className="text-sm text-gray-500">
                  This section is under development.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

interface NavItemProps {
  icon: React.ReactNode;
  label: string;
  active: boolean;
  onClick: () => void;
}

const NavItem: React.FC<NavItemProps> = ({ icon, label, active, onClick }) => (
  <button
    className={cn(
      "flex items-center w-full px-4 py-3 hover:bg-gray-50 transition-colors",
      active && "bg-gray-50 text-primary font-medium"
    )}
    onClick={onClick}
  >
    <span className="mr-3">{icon}</span>
    <span>{label}</span>
  </button>
);

export default Profile;