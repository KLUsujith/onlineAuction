import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { Eye, EyeOff, Mail, Lock, User, Check, AlertCircle } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import Captcha from '../components/ui/Captcha';
import toast from 'react-hot-toast';
import { cn } from '../utils/cn';

interface SignupFormData {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
  acceptTerms: boolean;
}

const Signup: React.FC = () => {
  const { 
    register, 
    handleSubmit, 
    watch,
    formState: { errors, isSubmitting } 
  } = useForm<SignupFormData>();
  
  const [showPassword, setShowPassword] = useState(false);
  const [captchaVerified, setCaptchaVerified] = useState(false);
  const { signup } = useAuth();
  const navigate = useNavigate();
  
  const password = watch('password', '');
  
  const passwordStrength = (password: string): { score: number; text: string } => {
    if (!password) return { score: 0, text: 'Very Weak' };
    
    let score = 0;
    
    // Length check
    if (password.length >= 8) score += 1;
    if (password.length >= 12) score += 1;
    
    // Complexity checks
    if (/[A-Z]/.test(password)) score += 1; // Uppercase
    if (/[a-z]/.test(password)) score += 1; // Lowercase
    if (/[0-9]/.test(password)) score += 1; // Numbers
    if (/[^A-Za-z0-9]/.test(password)) score += 1; // Special chars
    
    const strengthText = [
      'Very Weak',
      'Weak',
      'Fair',
      'Good',
      'Strong',
      'Very Strong'
    ][Math.min(score, 5)];
    
    return { score, text: strengthText };
  };
  
  const strength = passwordStrength(password);
  
  const onSubmit = async (data: SignupFormData) => {
    if (!captchaVerified) {
      toast.error('Please verify the captcha first');
      return;
    }
    
    if (data.password !== data.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    
    try {
      await signup(data.name, data.email, data.password);
      toast.success('Account created successfully!');
      navigate('/dashboard');
    } catch (error) {
      toast.error('Signup failed. Please try again.');
    }
  };
  
  const getStrengthColor = (score: number): string => {
    const colors = [
      'bg-red-500',        // Very Weak
      'bg-orange-500',     // Weak
      'bg-yellow-500',     // Fair
      'bg-lime-500',       // Good
      'bg-green-500',      // Strong
      'bg-emerald-500'     // Very Strong
    ];
    return colors[Math.min(score, 5)];
  };
  
  return (
    <div className="animate-fade-in">
      <div className="mb-8 text-center">
        <h1 className="text-2xl font-bold text-gray-900">Create your account</h1>
        <p className="text-gray-600 mt-2">
          Join PremiumBid and start buying or selling today
        </p>
      </div>
      
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div className="space-y-1">
          <label htmlFor="name" className="block text-sm font-medium text-gray-700">
            Full Name
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <User size={18} className="text-gray-400" />
            </div>
            <input
              id="name"
              type="text"
              autoComplete="name"
              {...register('name', { 
                required: 'Name is required',
                minLength: {
                  value: 2,
                  message: 'Name must be at least 2 characters'
                }
              })}
              className="input pl-10"
              placeholder="John Doe"
            />
          </div>
          {errors.name && (
            <p className="text-sm text-red-500">{errors.name.message}</p>
          )}
        </div>
        
        <div className="space-y-1">
          <label htmlFor="email" className="block text-sm font-medium text-gray-700">
            Email Address
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Mail size={18} className="text-gray-400" />
            </div>
            <input
              id="email"
              type="email"
              autoComplete="email"
              {...register('email', { 
                required: 'Email is required',
                pattern: {
                  value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                  message: 'Invalid email address'
                }
              })}
              className="input pl-10"
              placeholder="you@example.com"
            />
          </div>
          {errors.email && (
            <p className="text-sm text-red-500">{errors.email.message}</p>
          )}
        </div>
        
        <div className="space-y-1">
          <label htmlFor="password" className="block text-sm font-medium text-gray-700">
            Password
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Lock size={18} className="text-gray-400" />
            </div>
            <input
              id="password"
              type={showPassword ? 'text' : 'password'}
              autoComplete="new-password"
              {...register('password', { 
                required: 'Password is required',
                minLength: {
                  value: 8,
                  message: 'Password must be at least 8 characters'
                }
              })}
              className="input pl-10 pr-10"
              placeholder="••••••••"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute inset-y-0 right-0 pr-3 flex items-center"
              tabIndex={-1}
            >
              {showPassword ? (
                <EyeOff size={18} className="text-gray-400" />
              ) : (
                <Eye size={18} className="text-gray-400" />
              )}
            </button>
          </div>
          
          {password && (
            <div className="mt-2">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs">{strength.text}</span>
                <span className="text-xs">{strength.score}/6</span>
              </div>
              <div className="h-1.5 w-full bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className={cn("h-full transition-all", getStrengthColor(strength.score))}
                  style={{ width: `${(strength.score / 6) * 100}%` }}
                ></div>
              </div>
              
              <ul className="mt-2 grid grid-cols-2 gap-x-4 gap-y-1">
                <PasswordRequirement 
                  met={password.length >= 8}
                  label="At least 8 characters"
                />
                <PasswordRequirement 
                  met={/[A-Z]/.test(password)}
                  label="Uppercase letter"
                />
                <PasswordRequirement 
                  met={/[a-z]/.test(password)}
                  label="Lowercase letter"
                />
                <PasswordRequirement 
                  met={/[0-9]/.test(password)}
                  label="Number"
                />
                <PasswordRequirement 
                  met={/[^A-Za-z0-9]/.test(password)}
                  label="Special character"
                />
              </ul>
            </div>
          )}
          
          {errors.password && (
            <p className="text-sm text-red-500">{errors.password.message}</p>
          )}
        </div>
        
        <div className="space-y-1">
          <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700">
            Confirm Password
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Lock size={18} className="text-gray-400" />
            </div>
            <input
              id="confirmPassword"
              type={showPassword ? 'text' : 'password'}
              {...register('confirmPassword', { 
                required: 'Please confirm your password',
                validate: value => value === password || 'Passwords do not match'
              })}
              className="input pl-10"
              placeholder="••••••••"
            />
          </div>
          {errors.confirmPassword && (
            <p className="text-sm text-red-500">{errors.confirmPassword.message}</p>
          )}
        </div>
        
        <div className="flex items-start">
          <div className="flex items-center h-5">
            <input
              id="acceptTerms"
              type="checkbox"
              className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
              {...register('acceptTerms', { 
                required: 'You must accept the terms and conditions'
              })}
            />
          </div>
          <div className="ml-3 text-sm">
            <label htmlFor="acceptTerms" className="text-gray-700">
              I agree to the{' '}
              <Link to="/terms" className="text-primary hover:underline">
                Terms of Service
              </Link>{' '}
              and{' '}
              <Link to="/privacy" className="text-primary hover:underline">
                Privacy Policy
              </Link>
            </label>
            {errors.acceptTerms && (
              <p className="text-sm text-red-500 mt-1">{errors.acceptTerms.message}</p>
            )}
          </div>
        </div>
        
        <Captcha onVerify={setCaptchaVerified} />
        
        <button
          type="submit"
          className="btn btn-primary w-full"
          disabled={isSubmitting || !captchaVerified}
        >
          {isSubmitting ? 'Creating account...' : 'Create account'}
        </button>
        
        <p className="text-center text-sm text-gray-600">
          Already have an account?{' '}
          <Link to="/login" className="text-primary hover:underline font-medium">
            Sign in
          </Link>
        </p>
      </form>
    </div>
  );
};

interface PasswordRequirementProps {
  met: boolean;
  label: string;
}

const PasswordRequirement: React.FC<PasswordRequirementProps> = ({ met, label }) => (
  <li className="flex items-center text-xs">
    {met ? (
      <Check size={14} className="text-green-500 mr-1.5" />
    ) : (
      <AlertCircle size={14} className="text-gray-400 mr-1.5" />
    )}
    <span className={met ? 'text-gray-700' : 'text-gray-500'}>
      {label}
    </span>
  </li>
);

export default Signup;