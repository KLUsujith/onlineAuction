import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { Upload, Info, ArrowUpDown, DollarSign, Calendar, Clock, FileImage, X } from 'lucide-react';
import { useAuction } from '../hooks/useAuction';
import { useAuth } from '../hooks/useAuth';
import toast from 'react-hot-toast';
import { cn } from '../utils/cn';
import { AuctionType } from '../contexts/AuctionContext';

interface CreateAuctionFormData {
  title: string;
  description: string;
  type: AuctionType;
  startingPrice: number;
  category: string;
  startDate: string;
  endDate: string;
  imageUrl: string;
}

const categories = [
  'Electronics',
  'Fashion',
  'Home & Garden',
  'Collectibles',
  'Art',
  'Vehicles',
  'Toys & Hobbies',
  'Jewelry',
  'Books',
  'Sports',
  'Services',
  'Business & Industrial',
  'Travel',
  'Real Estate',
  'Other',
];

const CreateAuction: React.FC = () => {
  const { 
    register, 
    handleSubmit, 
    watch,
    formState: { errors, isSubmitting } 
  } = useForm<CreateAuctionFormData>();
  
  const [uploadedImage, setUploadedImage] = useState<string>('');
  const navigate = useNavigate();
  const { createAuction } = useAuction();
  const { user } = useAuth();
  
  const auctionType = watch('type', 'standard');
  
  // Sample image URLs for demo
  const sampleImages = [
    'https://images.pexels.com/photos/303383/pexels-photo-303383.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    'https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    'https://images.pexels.com/photos/5920756/pexels-photo-5920756.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  ];
  
  // For demo, we'll set a random image when uploading
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    // In a real app, this would upload the file to a server
    // For demo, we'll use a random sample image
    const randomImage = sampleImages[Math.floor(Math.random() * sampleImages.length)];
    setUploadedImage(randomImage);
    toast.success('Image uploaded successfully');
  };
  
  const onSubmit = async (data: CreateAuctionFormData) => {
    if (!user) {
      toast.error('You must be logged in to create an auction');
      navigate('/login');
      return;
    }
    
    try {
      const startDate = new Date(data.startDate);
      const endDate = new Date(data.endDate);
      
      // Validate dates
      if (startDate > endDate) {
        toast.error('End date must be after start date');
        return;
      }
      
      const imageToUse = uploadedImage || sampleImages[0];
      
      const auction = await createAuction({
        title: data.title,
        description: data.description,
        type: data.type,
        startingPrice: parseFloat(data.startingPrice.toString()),
        category: data.category,
        startDate,
        endDate,
        imageUrl: imageToUse,
        sellerId: user.id,
        sellerName: user.name,
      });
      
      toast.success('Auction created successfully!');
      navigate(`/auction/${auction.id}`);
    } catch (error) {
      toast.error('Failed to create auction. Please try again.');
    }
  };
  
  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold mb-8">Create New Auction</h1>
          
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
            {/* Basic Info Card */}
            <div className="card">
              <div className="card-header">
                <h2 className="card-title">Basic Information</h2>
                <p className="card-description">
                  Provide the essential details about what you're auctioning
                </p>
              </div>
              <div className="card-content space-y-6">
                {/* Title */}
                <div>
                  <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                    Auction Title
                  </label>
                  <input
                    id="title"
                    className={cn(
                      "input w-full",
                      errors.title && "border-red-500 focus-visible:ring-red-500"
                    )}
                    placeholder="e.g. '2023 MacBook Pro' or 'Website Development Services'"
                    {...register('title', { 
                      required: 'Title is required',
                      minLength: {
                        value: 5,
                        message: 'Title must be at least 5 characters'
                      },
                      maxLength: {
                        value: 100,
                        message: 'Title must not exceed 100 characters'
                      }
                    })}
                  />
                  {errors.title && (
                    <p className="mt-1 text-sm text-red-500">{errors.title.message}</p>
                  )}
                </div>
                
                {/* Description */}
                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    id="description"
                    rows={5}
                    className={cn(
                      "input w-full",
                      errors.description && "border-red-500 focus-visible:ring-red-500"
                    )}
                    placeholder="Provide detailed information about what you're selling or the service you need..."
                    {...register('description', { 
                      required: 'Description is required',
                      minLength: {
                        value: 20,
                        message: 'Description must be at least 20 characters'
                      }
                    })}
                  />
                  {errors.description && (
                    <p className="mt-1 text-sm text-red-500">{errors.description.message}</p>
                  )}
                </div>
                
                {/* Category */}
                <div>
                  <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
                    Category
                  </label>
                  <select
                    id="category"
                    className={cn(
                      "input w-full",
                      errors.category && "border-red-500 focus-visible:ring-red-500"
                    )}
                    {...register('category', { 
                      required: 'Category is required'
                    })}
                  >
                    <option value="">Select a category</option>
                    {categories.map(category => (
                      <option key={category} value={category}>{category}</option>
                    ))}
                  </select>
                  {errors.category && (
                    <p className="mt-1 text-sm text-red-500">{errors.category.message}</p>
                  )}
                </div>
              </div>
            </div>
            
            {/* Auction Type & Pricing */}
            <div className="card">
              <div className="card-header">
                <h2 className="card-title">Auction Type & Pricing</h2>
                <p className="card-description">
                  Choose the auction format and set your pricing
                </p>
              </div>
              <div className="card-content space-y-6">
                {/* Auction Type */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    Auction Type
                  </label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className={cn(
                      "relative p-4 border rounded-lg cursor-pointer transition-all",
                      auctionType === 'standard' 
                        ? "border-primary bg-primary/5" 
                        : "border-gray-200 hover:border-gray-300"
                    )}>
                      <input
                        type="radio"
                        id="typeStandard"
                        value="standard"
                        className="sr-only"
                        {...register('type', { required: true })}
                      />
                      <label 
                        htmlFor="typeStandard" 
                        className="flex flex-col cursor-pointer"
                      >
                        <span className="flex items-center">
                          <ArrowUpDown size={20} className="text-primary mr-2" />
                          <span className="font-medium">Standard Auction</span>
                        </span>
                        <span className="mt-2 text-sm text-gray-600">
                          Highest bidder wins. Ideal for selling items or collectibles.
                        </span>
                      </label>
                      {auctionType === 'standard' && (
                        <div className="absolute top-2 right-2 h-4 w-4 rounded-full bg-primary"></div>
                      )}
                    </div>
                    
                    <div className={cn(
                      "relative p-4 border rounded-lg cursor-pointer transition-all",
                      auctionType === 'reverse' 
                        ? "border-secondary bg-secondary/5" 
                        : "border-gray-200 hover:border-gray-300"
                    )}>
                      <input
                        type="radio"
                        id="typeReverse"
                        value="reverse"
                        className="sr-only"
                        {...register('type', { required: true })}
                      />
                      <label 
                        htmlFor="typeReverse" 
                        className="flex flex-col cursor-pointer"
                      >
                        <span className="flex items-center">
                          <ArrowUpDown size={20} className="text-secondary mr-2" />
                          <span className="font-medium">Reverse Auction</span>
                        </span>
                        <span className="mt-2 text-sm text-gray-600">
                          Lowest bidder wins. Perfect for finding service providers.
                        </span>
                      </label>
                      {auctionType === 'reverse' && (
                        <div className="absolute top-2 right-2 h-4 w-4 rounded-full bg-secondary"></div>
                      )}
                    </div>
                  </div>
                </div>
                
                {/* Starting Price */}
                <div>
                  <label htmlFor="startingPrice" className="block text-sm font-medium text-gray-700 mb-1">
                    {auctionType === 'standard' ? 'Starting Price' : 'Maximum Budget'}
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <DollarSign size={18} className="text-gray-500" />
                    </div>
                    <input
                      id="startingPrice"
                      type="number"
                      className={cn(
                        "input w-full pl-9",
                        errors.startingPrice && "border-red-500 focus-visible:ring-red-500"
                      )}
                      placeholder={auctionType === 'standard' ? 'Minimum starting bid' : 'Maximum budget for service'}
                      {...register('startingPrice', { 
                        required: 'Starting price is required',
                        min: {
                          value: 1,
                          message: 'Price must be greater than 0'
                        },
                        valueAsNumber: true
                      })}
                    />
                  </div>
                  {errors.startingPrice && (
                    <p className="mt-1 text-sm text-red-500">{errors.startingPrice.message}</p>
                  )}
                  <p className="mt-1 text-sm text-gray-500">
                    {auctionType === 'standard' 
                      ? 'This is the minimum amount someone must bid to start the auction.' 
                      : 'This is the maximum amount you are willing to pay for the service.'}
                  </p>
                </div>
              </div>
            </div>
            
            {/* Auction Timing */}
            <div className="card">
              <div className="card-header">
                <h2 className="card-title">Auction Schedule</h2>
                <p className="card-description">
                  Set when your auction starts and ends
                </p>
              </div>
              <div className="card-content space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Start Date */}
                  <div>
                    <label htmlFor="startDate" className="block text-sm font-medium text-gray-700 mb-1">
                      Start Date
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Calendar size={18} className="text-gray-500" />
                      </div>
                      <input
                        id="startDate"
                        type="datetime-local"
                        className={cn(
                          "input w-full pl-9",
                          errors.startDate && "border-red-500 focus-visible:ring-red-500"
                        )}
                        {...register('startDate', { 
                          required: 'Start date is required'
                        })}
                      />
                    </div>
                    {errors.startDate && (
                      <p className="mt-1 text-sm text-red-500">{errors.startDate.message}</p>
                    )}
                  </div>
                  
                  {/* End Date */}
                  <div>
                    <label htmlFor="endDate" className="block text-sm font-medium text-gray-700 mb-1">
                      End Date
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Clock size={18} className="text-gray-500" />
                      </div>
                      <input
                        id="endDate"
                        type="datetime-local"
                        className={cn(
                          "input w-full pl-9",
                          errors.endDate && "border-red-500 focus-visible:ring-red-500"
                        )}
                        {...register('endDate', { 
                          required: 'End date is required'
                        })}
                      />
                    </div>
                    {errors.endDate && (
                      <p className="mt-1 text-sm text-red-500">{errors.endDate.message}</p>
                    )}
                  </div>
                </div>
                
                <div className="flex items-start p-4 bg-blue-50 rounded-lg">
                  <Info size={18} className="text-blue-600 mt-0.5 flex-shrink-0" />
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-blue-800">Duration Tips</h3>
                    <p className="text-sm text-blue-600 mt-1">
                      We recommend auction durations between 3-10 days. Shorter auctions create urgency, 
                      while longer ones allow more bidders to find your listing.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Images */}
            <div className="card">
              <div className="card-header">
                <h2 className="card-title">Images</h2>
                <p className="card-description">
                  Add photos to showcase what you're selling or illustrate the service needed
                </p>
              </div>
              <div className="card-content">
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    Upload Images
                  </label>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Image upload zone */}
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 flex flex-col items-center justify-center cursor-pointer hover:border-primary transition-colors">
                      <input
                        type="file"
                        id="image"
                        className="hidden"
                        accept="image/*"
                        onChange={handleImageUpload}
                      />
                      <label htmlFor="image" className="cursor-pointer text-center">
                        <Upload size={32} className="mx-auto text-gray-400 mb-3" />
                        <p className="text-sm font-medium text-gray-900 mb-1">Click to upload</p>
                        <p className="text-xs text-gray-500">
                          PNG, JPG or WEBP (max. 5MB)
                        </p>
                      </label>
                    </div>
                    
                    {/* Preview of uploaded image */}
                    {uploadedImage && (
                      <div className="relative border rounded-lg overflow-hidden">
                        <img 
                          src={uploadedImage} 
                          alt="Preview" 
                          className="w-full h-40 object-cover"
                        />
                        <button
                          type="button"
                          onClick={() => setUploadedImage('')}
                          className="absolute top-2 right-2 w-8 h-8 bg-black/50 rounded-full flex items-center justify-center text-white hover:bg-black/70 transition-colors"
                        >
                          <X size={16} />
                        </button>
                        <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white text-xs py-1 px-2">
                          <div className="flex items-center">
                            <FileImage size={12} className="mr-1" />
                            <span>Primary Image</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <p className="mt-3 text-sm text-gray-500">
                    High-quality images increase bidding interest by up to 45%.
                  </p>
                </div>
              </div>
            </div>
            
            {/* Submit */}
            <div className="flex justify-between pt-6 border-t border-gray-200">
              <button
                type="button"
                className="btn btn-outline"
                onClick={() => navigate(-1)}
              >
                Cancel
              </button>
              <button
                type="submit"
                className={cn(
                  "btn",
                  auctionType === 'standard' ? "btn-primary" : "btn-secondary"
                )}
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Creating...' : 'Create Auction'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CreateAuction;