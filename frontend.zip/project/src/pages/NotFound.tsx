import React from 'react';
import { Link } from 'react-router-dom';
import { Home, Search, ArrowLeft } from 'lucide-react';

const NotFound: React.FC = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
      <div className="max-w-lg w-full text-center">
        <div className="mb-8">
          <h1 className="text-9xl font-bold text-primary">404</h1>
          <div className="h-1.5 w-16 bg-secondary mx-auto my-6"></div>
          <h2 className="text-3xl font-semibold mb-2">Page Not Found</h2>
          <p className="text-gray-600">
            The page you're looking for doesn't exist or has been moved.
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <Link to="/" className="btn btn-outline flex items-center justify-center">
            <Home size={18} className="mr-2" />
            Home
          </Link>
          <Link to="/auctions" className="btn btn-outline flex items-center justify-center">
            <Search size={18} className="mr-2" />
            Browse Auctions
          </Link>
          <button 
            onClick={() => window.history.back()}
            className="btn btn-outline flex items-center justify-center"
          >
            <ArrowLeft size={18} className="mr-2" />
            Go Back
          </button>
        </div>
        
        <div className="text-sm text-gray-500">
          <p>If you believe this is a mistake, please contact our support team.</p>
        </div>
      </div>
    </div>
  );
};

export default NotFound;