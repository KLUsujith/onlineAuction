import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Search, DollarSign, TrendingUp, TrendingDown, Shield, Clock } from 'lucide-react';
import { useAuction } from '../hooks/useAuction';
import { cn } from '../utils/cn';

const Home: React.FC = () => {
  const { featuredAuctions } = useAuction();
  
  return (
    <div className="pb-16">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-primary to-blue-700 text-white pt-32 pb-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            <div className="max-w-xl">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
                The Premium Online Auction Experience
              </h1>
              <p className="text-lg md:text-xl mb-8 text-blue-100">
                Join thousands of users buying and selling through our innovative platform.
                Featuring both standard and reverse auctions for maximum flexibility.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <Link to="/auctions" className="btn btn-lg btn-secondary">
                  Browse Auctions
                </Link>
                <Link to="/signup" className="btn btn-lg btn-outline border-white text-white hover:bg-white hover:text-primary">
                  Join Now
                </Link>
              </div>
            </div>
            
            <div className="hidden lg:block relative">
              <div className="bg-white p-6 rounded-lg shadow-lg transform rotate-3 hover:rotate-0 transition-transform duration-300">
                <div className="border-b pb-4 mb-4">
                  <h3 className="text-xl font-semibold text-gray-900">Vintage Camera Collection</h3>
                  <p className="text-gray-500">Standard Auction</p>
                </div>
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <p className="text-gray-600 text-sm">Current Bid</p>
                    <p className="text-2xl font-bold text-gray-900">$1,250.00</p>
                  </div>
                  <div>
                    <p className="text-gray-600 text-sm">Time Left</p>
                    <p className="text-gray-900 font-medium">2d 14h 32m</p>
                  </div>
                </div>
                <button className="btn btn-primary w-full">
                  Place Bid
                </button>
              </div>
              
              <div className="absolute -bottom-10 -left-10 bg-white p-6 rounded-lg shadow-lg transform -rotate-6 hover:rotate-0 transition-transform duration-300">
                <div className="border-b pb-4 mb-4">
                  <h3 className="text-xl font-semibold text-gray-900">Website Development</h3>
                  <p className="text-gray-500">Reverse Auction</p>
                </div>
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <p className="text-gray-600 text-sm">Current Bid</p>
                    <p className="text-2xl font-bold text-gray-900">$840.00</p>
                  </div>
                  <div>
                    <p className="text-gray-600 text-sm">Time Left</p>
                    <p className="text-gray-900 font-medium">5d 8h 12m</p>
                  </div>
                </div>
                <button className="btn btn-primary w-full">
                  Place Bid
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Wave separator */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 100" className="fill-white">
            <path d="M0,96L80,85.3C160,75,320,53,480,53.3C640,53,800,75,960,80C1120,85,1280,75,1360,69.3L1440,64L1440,320L1360,320C1280,320,1120,320,960,320C800,320,640,320,480,320C320,320,160,320,80,320L0,320Z"></path>
          </svg>
        </div>
      </section>
      
      {/* How It Works Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">How It Works</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Our platform offers two auction types to meet all your needs, with an easy-to-use interface and secure transactions.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
            {/* Standard Auction */}
            <div className="text-center md:text-left">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-6 text-primary">
                <TrendingUp size={28} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Standard Auctions</h3>
              <p className="text-gray-600 mb-6">
                In standard auctions, sellers list items and buyers compete with increasingly higher bids. 
                The highest bidder wins the auction when the time runs out.
              </p>
              <div className="space-y-4">
                <StepItem 
                  number={1} 
                  title="List Your Item" 
                  description="Set your starting price and auction duration"
                />
                <StepItem 
                  number={2} 
                  title="Buyers Place Bids" 
                  description="Watch as buyers compete with higher bids"
                />
                <StepItem 
                  number={3} 
                  title="Highest Bid Wins" 
                  description="When time expires, the highest bidder wins"
                />
                <StepItem 
                  number={4} 
                  title="Secure Transaction" 
                  description="Safe payment processing and delivery tracking"
                />
              </div>
            </div>
            
            {/* Reverse Auction */}
            <div className="text-center md:text-left">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-secondary/10 rounded-full mb-6 text-secondary">
                <TrendingDown size={28} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Reverse Auctions</h3>
              <p className="text-gray-600 mb-6">
                In reverse auctions, buyers post projects and sellers compete with lower bids.
                The lowest bidder typically wins the contract when time expires.
              </p>
              <div className="space-y-4">
                <StepItem 
                  number={1} 
                  title="Post Your Project" 
                  description="Specify your maximum budget and requirements"
                  variant="secondary"
                />
                <StepItem 
                  number={2} 
                  title="Sellers Place Bids" 
                  description="Service providers compete with lower prices"
                  variant="secondary"
                />
                <StepItem 
                  number={3} 
                  title="Lowest Bid Wins" 
                  description="Select from the most competitive offers"
                  variant="secondary"
                />
                <StepItem 
                  number={4} 
                  title="Complete Project" 
                  description="Funds are only released when you're satisfied"
                  variant="secondary"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Featured Auctions */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Featured Auctions</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Discover our most active auctions right now, from valuable collectibles to professional services.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredAuctions.map((auction) => (
              <Link 
                key={auction.id} 
                to={`/auction/${auction.id}`}
                className="group"
              >
                <div className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300">
                  <div className="relative h-48 overflow-hidden">
                    <img 
                      src={auction.imageUrl} 
                      alt={auction.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div className="absolute top-3 right-3">
                      <span className={cn(
                        "badge text-xs",
                        auction.type === 'standard' 
                          ? "bg-primary text-white" 
                          : "bg-secondary text-gray-900"
                      )}>
                        {auction.type === 'standard' ? 'Standard' : 'Reverse'} Auction
                      </span>
                    </div>
                  </div>
                  <div className="p-5">
                    <h3 className="text-lg font-semibold line-clamp-1 mb-2 group-hover:text-primary transition-colors">
                      {auction.title}
                    </h3>
                    <p className="text-gray-600 text-sm line-clamp-2 mb-4">
                      {auction.description}
                    </p>
                    <div className="flex justify-between items-center pt-4 border-t border-gray-100">
                      <div>
                        <p className="text-xs text-gray-500">Current {auction.type === 'standard' ? 'Bid' : 'Offer'}</p>
                        <p className="text-lg font-bold text-gray-900">
                          ${auction.currentPrice.toLocaleString()}
                        </p>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock size={14} className="text-gray-500" />
                        <span className="text-xs text-gray-500">
                          {Math.ceil((auction.endDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} days left
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Link to="/auctions" className="btn btn-lg btn-primary">
              View All Auctions
            </Link>
          </div>
        </div>
      </section>
      
      {/* Features */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose PremiumBid</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Our platform offers unique benefits that make buying and selling easier, safer, and more effective.
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<Shield size={24} />}
              title="Secure Transactions"
              description="All payments are protected with escrow service and released only when both parties are satisfied."
            />
            <FeatureCard 
              icon={<Search size={24} />}
              title="Advanced Search"
              description="Find exactly what you're looking for with our powerful filtering and search capabilities."
            />
            <FeatureCard 
              icon={<DollarSign size={24} />}
              title="Competitive Pricing"
              description="Get the best market value through our competitive bidding system for both auction types."
            />
            <FeatureCard 
              icon={<Clock size={24} />}
              title="Real-time Updates"
              description="Stay informed with instant notifications about your auctions, bids, and messages."
            />
            <FeatureCard 
              icon={<TrendingUp size={24} />}
              title="Market Analytics"
              description="Make informed decisions with price history and market trend data for similar items."
            />
            <FeatureCard 
              icon={<ArrowRight size={24} />}
              title="Easy Listing"
              description="Create professional auction listings in minutes with our user-friendly interface."
            />
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 bg-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Start?</h2>
          <p className="text-lg text-blue-100 max-w-2xl mx-auto mb-10">
            Join thousands of satisfied users already buying and selling on our platform.
            Create your account today and experience the future of online auctions.
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Link to="/signup" className="btn btn-lg btn-secondary">
              Create Account
            </Link>
            <Link to="/auctions" className="btn btn-lg btn-outline border-white text-white hover:bg-white hover:text-primary">
              Browse Auctions
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

interface StepItemProps {
  number: number;
  title: string;
  description: string;
  variant?: 'primary' | 'secondary';
}

const StepItem: React.FC<StepItemProps> = ({ 
  number, 
  title, 
  description,
  variant = 'primary'
}) => (
  <div className="flex items-start">
    <div className={cn(
      "flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-full text-white text-sm font-medium mr-4",
      variant === 'primary' ? 'bg-primary' : 'bg-secondary'
    )}>
      {number}
    </div>
    <div>
      <h4 className="text-lg font-semibold">{title}</h4>
      <p className="text-gray-600">{description}</p>
    </div>
  </div>
);

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description }) => (
  <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 hover:shadow-md transition-shadow duration-300">
    <div className="inline-flex items-center justify-center w-12 h-12 bg-primary/10 rounded-full mb-4 text-primary">
      {icon}
    </div>
    <h3 className="text-xl font-semibold mb-3">{title}</h3>
    <p className="text-gray-600">{description}</p>
  </div>
);

export default Home;