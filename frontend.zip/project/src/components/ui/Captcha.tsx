import React, { useState, useEffect } from 'react';
import { RefreshCw } from 'lucide-react';
import { cn } from '../../utils/cn';

interface CaptchaProps {
  onVerify: (verified: boolean) => void;
  className?: string;
}

// Function to generate a random captcha
const generateCaptcha = (): string => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  let captcha = '';
  
  for (let i = 0; i < 6; i++) {
    captcha += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  
  return captcha;
};

// Function to add visual noise to make captcha more secure
const CaptchaCanvas: React.FC<{ captcha: string }> = ({ captcha }) => {
  const canvasRef = React.useRef<HTMLCanvasElement>(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw background
    ctx.fillStyle = '#f3f4f6';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Add noise (dots)
    for (let i = 0; i < 100; i++) {
      ctx.fillStyle = `rgba(${Math.floor(Math.random() * 200)}, ${Math.floor(Math.random() * 200)}, ${Math.floor(Math.random() * 200)}, 0.5)`;
      ctx.beginPath();
      ctx.arc(
        Math.random() * canvas.width,
        Math.random() * canvas.height,
        Math.random() * 2,
        0,
        Math.PI * 2
      );
      ctx.fill();
    }
    
    // Add noise (lines)
    for (let i = 0; i < 5; i++) {
      ctx.strokeStyle = `rgba(${Math.floor(Math.random() * 200)}, ${Math.floor(Math.random() * 200)}, ${Math.floor(Math.random() * 200)}, 0.5)`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(Math.random() * canvas.width, Math.random() * canvas.height);
      ctx.lineTo(Math.random() * canvas.width, Math.random() * canvas.height);
      ctx.stroke();
    }
    
    // Draw captcha text
    ctx.font = 'bold 24px Arial';
    const textWidth = ctx.measureText(captcha).width;
    const startX = (canvas.width - textWidth) / 2;
    
    // Draw each character with slight variations
    for (let i = 0; i < captcha.length; i++) {
      ctx.save();
      ctx.translate(
        startX + i * (textWidth / captcha.length),
        canvas.height / 2 + Math.random() * 6 - 3
      );
      ctx.rotate((Math.random() * 10 - 5) * Math.PI / 180);
      ctx.fillStyle = `rgb(${Math.floor(Math.random() * 100)}, ${Math.floor(Math.random() * 100)}, ${Math.floor(Math.random() * 100)})`;
      ctx.fillText(captcha[i], 0, 0);
      ctx.restore();
    }
  }, [captcha]);
  
  return (
    <canvas 
      ref={canvasRef}
      width={200}
      height={70}
      className="border border-gray-300 rounded-md"
    />
  );
};

const Captcha: React.FC<CaptchaProps> = ({ onVerify, className }) => {
  const [captcha, setCaptcha] = useState(generateCaptcha());
  const [inputValue, setInputValue] = useState('');
  const [error, setError] = useState(false);
  const [verified, setVerified] = useState(false);
  
  const refreshCaptcha = () => {
    setCaptcha(generateCaptcha());
    setInputValue('');
    setError(false);
    setVerified(false);
    onVerify(false);
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
    setError(false);
  };
  
  const validateCaptcha = () => {
    if (inputValue.toLowerCase() === captcha.toLowerCase()) {
      setVerified(true);
      onVerify(true);
    } else {
      setError(true);
      onVerify(false);
      // Generate a new captcha after a failed attempt
      setTimeout(refreshCaptcha, 1000);
    }
  };
  
  useEffect(() => {
    // Generate initial captcha
    setCaptcha(generateCaptcha());
  }, []);
  
  return (
    <div className={cn("space-y-3", className)}>
      <div className="flex justify-between items-center">
        <label className="block text-sm font-medium text-gray-700">
          Verification
        </label>
        <button 
          type="button"
          onClick={refreshCaptcha}
          className="text-gray-500 hover:text-gray-700 focus:outline-none"
          aria-label="Refresh captcha"
        >
          <RefreshCw size={16} />
        </button>
      </div>
      
      <div className="flex justify-center">
        <CaptchaCanvas captcha={captcha} />
      </div>
      
      <div>
        {verified ? (
          <div className="flex items-center justify-center p-2 bg-green-50 text-green-700 rounded-md text-sm">
            Captcha verified successfully
          </div>
        ) : (
          <div className="space-y-2">
            <input
              type="text"
              value={inputValue}
              onChange={handleChange}
              placeholder="Enter the characters above"
              className={cn(
                "input w-full",
                error && "border-red-500 focus-visible:ring-red-500"
              )}
              aria-invalid={error}
            />
            
            {error && (
              <p className="text-sm text-red-500">
                Incorrect captcha. Please try again.
              </p>
            )}
            
            <button
              type="button"
              onClick={validateCaptcha}
              className="btn btn-primary w-full"
              disabled={inputValue.length === 0}
            >
              Verify
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Captcha;