import React from 'react';
import { Outlet, Link } from 'react-router-dom';
import { Gavel } from 'lucide-react';

const AuthLayout: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Left side - Brand/Logo area */}
      <div className="bg-primary text-white md:w-1/2 flex flex-col justify-center items-center p-8 md:p-12">
        <div className="max-w-md mx-auto text-center">
          <Link to="/" className="inline-flex items-center gap-2 mb-8">
            <Gavel size={32} className="text-secondary" />
            <span className="text-3xl font-bold">PremiumBid</span>
          </Link>
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Transform the Way You Auction</h1>
          <p className="text-lg text-gray-100 mb-8">
            Join our premium auction platform for the most competitive bidding experience, with both
            standard and reverse auction capabilities.
          </p>
          <div className="hidden md:block">
            <div className="flex -space-x-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <div 
                  key={i}
                  className="w-12 h-12 rounded-full bg-white/20 border-2 border-white flex items-center justify-center text-xs font-medium"
                >
                  {String.fromCharCode(64 + i)}
                </div>
              ))}
              <div className="w-12 h-12 rounded-full bg-secondary text-primary flex items-center justify-center text-xs font-bold">
                +5K
              </div>
            </div>
            <p className="mt-4 text-sm">
              Join thousands of satisfied users already on our platform
            </p>
          </div>
        </div>
      </div>
      
      {/* Right side - Auth form area */}
      <div className="bg-white md:w-1/2 flex justify-center items-center p-8">
        <div className="w-full max-w-md">
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default AuthLayout;