import React, { createContext, useState, useEffect } from 'react';

export type AuctionType = 'standard' | 'reverse';

export interface Bid {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  timestamp: Date;
}

export interface Auction {
  id: string;
  title: string;
  description: string;
  type: AuctionType;
  startingPrice: number;
  currentPrice: number;
  imageUrl: string;
  sellerId: string;
  sellerName: string;
  startDate: Date;
  endDate: Date;
  status: 'upcoming' | 'active' | 'ended';
  category: string;
  bids: Bid[];
  watchCount: number;
}

interface AuctionContextType {
  auctions: Auction[];
  featuredAuctions: Auction[];
  getUserAuctions: (userId: string) => Auction[];
  getAuctionById: (id: string) => Auction | undefined;
  createAuction: (auction: Omit<Auction, 'id' | 'bids' | 'status' | 'currentPrice' | 'watchCount'>) => Promise<Auction>;
  placeBid: (auctionId: string, userId: string, userName: string, amount: number) => Promise<void>;
  toggleWatchlist: (auctionId: string) => void;
  loading: boolean;
  error: string | null;
}

export const AuctionContext = createContext<AuctionContextType | undefined>(undefined);

// Sample data for demo purposes
const generateSampleAuctions = (): Auction[] => {
  const now = new Date();
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  
  const nextWeek = new Date(now);
  nextWeek.setDate(nextWeek.getDate() + 7);
  
  return [
    {
      id: '1',
      title: 'Apple MacBook Pro M2',
      description: 'Brand new MacBook Pro with M2 chip, 16GB RAM, and 512GB SSD.',
      type: 'standard',
      startingPrice: 1200,
      currentPrice: 1350,
      imageUrl: 'https://images.pexels.com/photos/303383/pexels-photo-303383.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      sellerId: '2',
      sellerName: 'TechStore',
      startDate: new Date(now.getTime() - 86400000), // Yesterday
      endDate: tomorrow,
      status: 'active',
      category: 'Electronics',
      bids: [
        {
          id: 'b1',
          userId: '3',
          userName: 'bidder1',
          amount: 1250,
          timestamp: new Date(now.getTime() - 3600000)
        },
        {
          id: 'b2',
          userId: '4',
          userName: 'bidder2',
          amount: 1350,
          timestamp: new Date(now.getTime() - 1800000)
        }
      ],
      watchCount: 24
    },
    {
      id: '2',
      title: 'Website Development Project',
      description: 'Looking for a developer to build a 5-page website with contact form and booking system.',
      type: 'reverse',
      startingPrice: 5000,
      currentPrice: 3200,
      imageUrl: 'https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      sellerId: '5',
      sellerName: 'BusinessOwner',
      startDate: new Date(now.getTime() - 172800000), // 2 days ago
      endDate: nextWeek,
      status: 'active',
      category: 'Services',
      bids: [
        {
          id: 'b3',
          userId: '6',
          userName: 'developer1',
          amount: 4500,
          timestamp: new Date(now.getTime() - 86400000)
        },
        {
          id: 'b4',
          userId: '7',
          userName: 'developer2',
          amount: 3800,
          timestamp: new Date(now.getTime() - 43200000)
        },
        {
          id: 'b5',
          userId: '8',
          userName: 'developer3',
          amount: 3200,
          timestamp: new Date(now.getTime() - 21600000)
        }
      ],
      watchCount: 17
    },
    {
      id: '3',
      title: 'Vintage Rolex Submariner',
      description: 'Authentic 1985 Rolex Submariner in excellent condition with original box and papers.',
      type: 'standard',
      startingPrice: 8000,
      currentPrice: 9750,
      imageUrl: 'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      sellerId: '9',
      sellerName: 'VintageCollector',
      startDate: new Date(now.getTime() - 259200000), // 3 days ago
      endDate: new Date(now.getTime() + 172800000), // 2 days from now
      status: 'active',
      category: 'Luxury',
      bids: [
        {
          id: 'b6',
          userId: '10',
          userName: 'collector1',
          amount: 8500,
          timestamp: new Date(now.getTime() - 172800000)
        },
        {
          id: 'b7',
          userId: '11',
          userName: 'collector2',
          amount: 9250,
          timestamp: new Date(now.getTime() - 86400000)
        },
        {
          id: 'b8',
          userId: '12',
          userName: 'collector3',
          amount: 9750,
          timestamp: new Date(now.getTime() - 43200000)
        }
      ],
      watchCount: 52
    },
    {
      id: '4',
      title: 'Office Cleaning Services',
      description: 'Seeking professional cleaning services for a 3,000 sq ft office space, twice weekly.',
      type: 'reverse',
      startingPrice: 1500,
      currentPrice: 950,
      imageUrl: 'https://images.pexels.com/photos/5920756/pexels-photo-5920756.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      sellerId: '13',
      sellerName: 'OfficeMgr',
      startDate: new Date(now.getTime() - 345600000), // 4 days ago
      endDate: new Date(now.getTime() + 345600000), // 4 days from now
      status: 'active',
      category: 'Services',
      bids: [
        {
          id: 'b9',
          userId: '14',
          userName: 'cleaner1',
          amount: 1200,
          timestamp: new Date(now.getTime() - 259200000)
        },
        {
          id: 'b10',
          userId: '15',
          userName: 'cleaner2',
          amount: 1050,
          timestamp: new Date(now.getTime() - 172800000)
        },
        {
          id: 'b11',
          userId: '16',
          userName: 'cleaner3',
          amount: 950,
          timestamp: new Date(now.getTime() - 86400000)
        }
      ],
      watchCount: 8
    }
  ];
};

export const AuctionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [auctions, setAuctions] = useState<Auction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Simulate fetching auctions from API
    const loadAuctions = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 1000));
        setAuctions(generateSampleAuctions());
      } catch (err) {
        setError('Failed to load auctions');
      } finally {
        setLoading(false);
      }
    };
    
    loadAuctions();
  }, []);

  const featuredAuctions = auctions.filter(
    auction => auction.status === 'active' && auction.bids.length > 0
  ).sort(
    (a, b) => b.bids.length - a.bids.length
  ).slice(0, 6);

  const getUserAuctions = (userId: string) => {
    return auctions.filter(
      auction => auction.sellerId === userId || auction.bids.some(bid => bid.userId === userId)
    );
  };

  const getAuctionById = (id: string) => {
    return auctions.find(auction => auction.id === id);
  };

  const createAuction = async (auctionData: Omit<Auction, 'id' | 'bids' | 'status' | 'currentPrice' | 'watchCount'>) => {
    setLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const newAuction: Auction = {
        ...auctionData,
        id: `a${auctions.length + 1}`,
        status: new Date() < auctionData.startDate ? 'upcoming' : 'active',
        currentPrice: auctionData.startingPrice,
        bids: [],
        watchCount: 0
      };
      
      setAuctions(prev => [...prev, newAuction]);
      return newAuction;
    } catch (err) {
      setError('Failed to create auction');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const placeBid = async (auctionId: string, userId: string, userName: string, amount: number) => {
    setLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setAuctions(prev => prev.map(auction => {
        if (auction.id === auctionId) {
          const newBid: Bid = {
            id: `b${Math.random().toString(36).substr(2, 9)}`,
            userId,
            userName,
            amount,
            timestamp: new Date()
          };
          
          return {
            ...auction,
            bids: [...auction.bids, newBid],
            currentPrice: amount
          };
        }
        return auction;
      }));
    } catch (err) {
      setError('Failed to place bid');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const toggleWatchlist = (auctionId: string) => {
    setAuctions(prev => prev.map(auction => {
      if (auction.id === auctionId) {
        return {
          ...auction,
          watchCount: auction.watchCount + 1 // In a real app, this would toggle based on user's watchlist
        };
      }
      return auction;
    }));
  };

  return (
    <AuctionContext.Provider 
      value={{ 
        auctions, 
        featuredAuctions,
        getUserAuctions, 
        getAuctionById, 
        createAuction, 
        placeBid, 
        toggleWatchlist,
        loading, 
        error 
      }}
    >
      {children}
    </AuctionContext.Provider>
  );
};